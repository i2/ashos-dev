import sys
import os

def main():
    os.system("btrfs sub snap -r / /.base/base-0")
    os.system("btrfs sub snap -r / /.overlays/overlay-0")
    os.system("btrfs sub snap -r /boot /.boot/boot-0")
    os.system("btrfs sub snap /.overlays/overlay-0 /.overlays/overlay-tmp")
    os.system("btrfs sub snap -r /etc /.etc/etc-0")
    os.system("btrfs sub set-default /.overlays/overlay-tmp")
    os.system("cp /etc/astpk.d/startup-service /etc/systemd/system/recp.service")
    os.system("sed -i s,@,@.overlays/overlay-tmp, /etc/fstab")
    os.system("sed -i s,subvol=@,subvol=@.overlays/overlay-tmp, /boot/grub/grub.cfg")


main()