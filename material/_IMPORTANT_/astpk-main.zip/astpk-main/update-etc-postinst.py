import os
import sys

args = list(sys.argv)

def main(args):
    os.system("umount /etc")
    os.system("mkdir /etc-tmp")
    os.system(f"mount {args[1]} -o subvol=@etc,compress=zstd,noatime /etc-tmp")
    os.system("cp -r /etc-tmp/* /etc/")
    os.system("umount /etc-tmp")
    os.system(f"mount {args[1]} -o subvol=@etc,compress=zstd,noatime /etc")

    os.system(f"umount /boot/*")
    os.system("umount /boot")
    os.system("mkdir /boot-tmp")
    os.system(f"mount {args[1]} -o subvol=@boot,compress=zstd,noatime /boot-tmp")
    os.system("cp -r /boot-tmp/* /boot/")
    os.system("umount /boot-tmp")
    os.system(f"mount {args[1]} -o subvol=@boot,compress=zstd,noatime /boot")

main(args)