#!/usr/bin/python3
import os
import sys
import subprocess

args = list(sys.argv)
# etc-update, remove, rm-overlay, pac
def get_overlay():
    coverlay = open("/etc/astpk.d/astpk-coverlay","r")
    overlay = coverlay.readline()
    coverlay.close()
    return(overlay)

def get_part():
    cpart = open("/etc/astpk.d/astpk-part","r")
    part = cpart.readline()
    cpart.close()
    return(part)

def deploy(overlay):
    untmp()
    etc = overlay
    mount = str(subprocess.check_output("mount",shell=True))
    if "tmp0" in mount:
        tmp = "tmp"
    else:
        tmp = "tmp0"
    os.system(f"btrfs sub snap /.overlays/overlay-{overlay} /.overlays/overlay-{tmp}")
    os.system(f"btrfs sub snap /.etc/etc-{overlay} /.etc/etc-{tmp}")
    os.system(f"btrfs sub snap /.var/var-{overlay} /.var/var-{tmp}")
    os.system(f"btrfs sub snap /.boot/boot-{overlay} /.boot/boot-{tmp}")
    os.system(f"mkdir /.overlays/overlay-{tmp}/etc")
    os.system(f"mkdir /.overlays/overlay-{tmp}/var")
    os.system(f"mkdir /.overlays/overlay-{tmp}/boot")
    os.system(f"cp --reflink=auto -r /.etc/etc-{etc}/* /.overlays/overlay-{tmp}/etc")
    os.system(f"cp --reflink=auto -r /.var/var-{etc}/* /.overlays/overlay-{tmp}/var")
    os.system(f"cp --reflink=auto -r /.boot/boot-{etc}/* /.overlays/overlay-{tmp}/boot")
    os.system(f"echo '{overlay}' > /etc/astpk.d/astpk-coverlay")
    os.system(f"echo '{etc}' > /etc/astpk.d/astpk-cetc")
    switchtmp()

def clone(overlay):
    i = 0
    overlays = os.listdir("/.overlays")
    etcs = os.listdir("/.etc")
    vars = os.listdir("/.var")
    boots = os.listdir("/.boot")
    overlays.append(etcs)
    overlays.append(vars)
    overlays.append(boots)
    while True:
        i+=1
        if str(f"overlay-{i}") not in overlays and str(f"etc-{i}") not in overlays and str(f"var-{i}") not in overlays and str(f"boot-{i}") not in overlays:
            os.system(f"btrfs sub snap -r /.overlays/overlay-{overlay} /.overlays/overlay-{i}")
            os.system(f"btrfs sub snap -r /.etc/etc-{overlay} /.etc/etc-{i}")
            os.system(f"btrfs sub snap -r /.etc/var-{overlay} /.var/var-{i}")
            os.system(f"btrfs sub snap -r /.etc/boot-{overlay} /.boot/boot-{i}")
            break

def new_overlay():
    i = 0
    overlays = os.listdir("/.overlays")
    etcs = os.listdir("/.etc")
    vars = os.listdir("/.var")
    boots = os.listdir("/.boot")
    overlays.append(etcs)
    overlays.append(vars)
    overlays.append(boots)
    while True:
        i += 1
        if str(f"overlay-{i}") not in overlays and str(f"etc-{i}") not in overlays and str(f"var-{i}") not in overlays and str(f"boot-{i}") not in overlays:
            os.system(f"btrfs sub snap -r /.base/base /.overlays/overlay-{i}")
            os.system(f"btrfs sub snap -r /.etc/etc-0 /.etc/etc-{i}")
            os.system(f"btrfs sub snap -r /.var/var-0 /.var/var-{i}")
            os.system(f"btrfs sub snap -r /.boot/boot-0 /.boot/boot-{i}")
            break


def chroot(overlay):
    unchr()
    etc = overlay
    os.system(f"btrfs sub snap /.overlays/overlay-{overlay} /.overlays/overlay-chr")
    os.system(f"btrfs sub snap /.etc/etc-{overlay} /.etc/etc-chr")
    os.system(f"btrfs sub snap /.var/var-{overlay} /.var/var-chr")
    os.system(f"btrfs sub snap /.boot/boot-{overlay} /.boot/boot-chr")
    os.system(f"cp -r --reflink=auto /.etc/etc-chr/* /.overlays/overlay-chr/etc")
    os.system(f"cp -r --reflink=auto /.var/var-chr/* /.overlays/overlay-chr/var")
    os.system(f"cp -r --reflink=auto /.boot/boot-chr/* /.overlays/overlay-chr/boot")
    os.system("pacstrap /.overlays/overlay-chr")
    os.system(f"arch-chroot /.overlays/overlay-chr")
    os.system(f"btrfs sub del /.overlays/overlay-{overlay}")
    os.system(f"btrfs sub snap -r /.overlays/overlay-chr /.overlays/overlay-{overlay}")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/etc/* /.etc/etc-chr")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/var/* /.var/var-chr")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/boot/* /.boot/boot-chr")
    os.system(f"btrfs sub del /.etc/etc-{etc}")
    os.system(f"btrfs sub del /.var/var-{etc}")
    os.system(f"btrfs sub del /.boot/boot-{etc}")
    os.system(f"btrfs sub snap -r /.etc/etc-chr /.etc/etc-{etc}")
    os.system(f"btrfs sub snap -r /.boot/boot-chr /.boot/boot-{etc}")

def unchr():
    os.system(f"btrfs sub del /.etc/etc-chr")
    os.system(f"btrfs sub del /.var/var-chr")
    os.system(f"btrfs sub del /.boot/boot-chr")
    os.system(f"btrfs sub del /.overlays/overlay-chr")

def untmp():
    mount = str(subprocess.check_output("mount",shell=True))
    if "tmp0" in mount:
        tmp = "tmp"
    else:
        tmp = "tmp0"
    os.system(f"btrfs sub del /.overlays/overlay-{tmp}")
    os.system(f"btrfs sub del /.etc/etc-{tmp}")
    os.system(f"btrfs sub del /.var/var-{tmp}")
    os.system(f"btrfs sub del /.boot/boot-{tmp}")

def install(overlay,pkg):
    unchr()
    etc = overlay
    os.system(f"btrfs sub snap /.overlays/overlay-{overlay} /.overlays/overlay-chr")
    os.system(f"btrfs sub snap /.etc/etc-{overlay} /.etc/etc-chr")
    os.system(f"btrfs sub snap /.var/var-{overlay} /.var/var-chr")
    os.system(f"btrfs sub snap /.boot/boot-{overlay} /.boot/boot-chr")
    os.system(f"cp -r --reflink=auto /.etc/etc-chr/* /.overlays/overlay-chr/etc")
    os.system(f"cp -r --reflink=auto /.var/var-chr/* /.overlays/overlay-chr/var")
    os.system(f"cp -r --reflink=auto /.boot/boot-chr/* /.overlays/overlay-chr/boot")
    os.system("pacstrap /.overlays/overlay-chr")
    os.system(f"pacman -r /.overlays/overlay-chr -S {pkg}")
    os.system(f"btrfs sub del /.overlays/overlay-{overlay}")
    os.system(f"btrfs sub snap -r /.overlays/overlay-chr /.overlays/overlay-{overlay}")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/etc/* /.etc/etc-chr")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/var/* /.var/var-chr")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/boot/* /.boot/boot-chr")
    os.system(f"btrfs sub del /.etc/etc-{etc}")
    os.system(f"btrfs sub del /.var/var-{etc}")
    os.system(f"btrfs sub del /.boot/boot-{etc}")
    os.system(f"btrfs sub snap -r /.etc/etc-chr /.etc/etc-{etc}")
    os.system(f"btrfs sub snap -r /.var/var-chr /.var/var-{etc}")
    os.system(f"btrfs sub snap -r /.boot/boot-chr /.boot/boot-{etc}")

def upgrade(overlay):
    unchr()
    etc = overlay
    os.system(f"btrfs sub snap /.overlays/overlay-{overlay} /.overlays/overlay-chr")
    os.system(f"btrfs sub snap /.etc/etc-{overlay} /.etc/etc-chr")
    os.system(f"btrfs sub snap /.var/var-{overlay} /.var/var-chr")
    os.system(f"btrfs sub snap /.boot/boot-{overlay} /.boot/boot-chr")
    os.system(f"cp -r --reflink=auto /.etc/etc-chr/* /.overlays/overlay-chr/etc")
    os.system(f"cp -r --reflink=auto /.var/var-chr/* /.overlays/overlay-chr/var")
    os.system(f"cp -r --reflink=auto /.boot/boot-chr/* /.overlays/overlay-chr/boot")
    os.system("pacstrap /.overlays/overlay-chr")
    os.system(f"pacman -r /.overlays/overlay-chr -Syyu")
    os.system(f"btrfs sub del /.overlays/overlay-{overlay}")
    os.system(f"btrfs sub snap -r /.overlays/overlay-chr /.overlays/overlay-{overlay}")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/etc/* /.etc/etc-chr")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/var/* /.var/var-chr")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/boot/* /.boot/boot-chr")
    os.system(f"btrfs sub del /.etc/etc-{etc}")
    os.system(f"btrfs sub del /.var/var-{etc}")
    os.system(f"btrfs sub del /.boot/boot-{etc}")
    os.system(f"btrfs sub snap -r /.etc/etc-chr /.etc/etc-{etc}")
    os.system(f"btrfs sub snap -r /.var/var-chr /.var/var-{etc}")
    os.system(f"btrfs sub snap -r /.boot/boot-chr /.boot/boot-{etc}")

def cupgrade(overlay):
    untmp()
    unchr()
    etc = overlay
    mount = str(subprocess.check_output("mount",shell=True))
    if "tmp0" in mount:
        tmp = "tmp"
    else:
        tmp = "tmp0"
    i = 0
    overlays = os.listdir("/.overlays")
    etcs = os.listdir("/.etc")
    vars = os.listdir("/.var")
    boots = os.listdir("/.boot")
    overlays.append(etcs)
    overlays.append(vars)
    overlays.append(boots)
    while True:
        i += 1
        if str(f"overlay-{i}") not in overlays and str(f"etc-{i}") not in overlays and str(f"var-{i}") not in overlays and str(f"boot-{i}") not in overlays:
            os.system(f"btrfs sub snap /.overlays/overlay-{overlay} /.overlays/overlay-chr")
            os.system(f"btrfs sub snap /.etc/etc-{overlay} /.etc/etc-chr")
            os.system(f"btrfs sub snap /.var/var-{overlay} /.var/var-chr")
            os.system(f"btrfs sub snap /.boot/boot-{overlay} /.boot/boot-chr")
            os.system(f"cp -r --reflink=auto /.etc/etc-chr/* /.overlays/overlay-chr/etc")
            os.system(f"cp -r --reflink=auto /.var/var-chr/* /.overlays/overlay-chr/var")
            os.system(f"cp -r --reflink=auto /.boot/boot-chr/* /.overlays/overlay-chr/boot")
            os.system("pacstrap /.overlays/overlay-chr")
            os.system(f"pacman -r /.overlays/overlay-chr -Syyu")
            os.system(f"btrfs sub del /.overlays/overlay-{int(i)}")
            os.system(f"btrfs sub snap -r /.overlays/overlay-chr /.overlays/overlay-{int(i)}")
            os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/etc/* /.etc/etc-chr")
            os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/var/* /.var/var-chr")
            os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/boot/* /.boot/boot-chr")
            os.system(f"btrfs sub del /.etc/etc-{int(etc)}")
            os.system(f"btrfs sub del /.var/var-{int(etc)}")
            os.system(f"btrfs sub del /.boot/boot-{int(etc)}")
            os.system(f"btrfs sub snap -r /.etc/etc-chr /.etc/etc-{int(etc)}")
            os.system(f"btrfs sub snap -r /.var/var-chr /.var/var-{int(etc)}")
            os.system(f"btrfs sub snap -r /.boot/boot-chr /.boot/boot-{int(etc)}")
#            os.system(f"btrfs sub snap /.overlay/overlay-{int(i)}/* /.overlays/overlay-{tmp}/etc") #
            os.system(f"cp --reflink=auto -r /.etc/etc-{int(i)}/* /.overlays/overlay-{tmp}/etc")
            os.system(f"cp --reflink=auto -r /.var/var-{int(i)}/* /.overlays/overlay-{tmp}/var")
            os.system(f"cp --reflink=auto -r /.boot/boot-{int(i)}/* /.overlays/overlay-{tmp}/boot")
            switchtmp()
            break

def cinstall(overlay,pkg):
    untmp()
    unchr()
    etc = overlay
    mount = str(subprocess.check_output("mount",shell=True))
    if "tmp0" in mount:
        tmp = "tmp"
    else:
        tmp = "tmp0"
    i = 0
    overlays = os.listdir("/.overlays")
    etcs = os.listdir("/.etc")
    vars = os.listdir("/.var")
    boots = os.listdir("/.boot")
    overlays.append(etcs)
    overlays.append(vars)
    overlays.append(boots)
    while True:
        i += 1
        if str(f"overlay-{i}") not in overlays and str(f"etc-{i}") not in overlays and str(f"var-{i}") not in overlays and str(f"boot-{i}") not in overlays:
            os.system(f"btrfs sub snap /.overlays/overlay-{overlay} /.overlays/overlay-chr")
            os.system(f"btrfs sub snap /.etc/etc-{overlay} /.etc/etc-chr")
            os.system(f"btrfs sub snap /.var/etc-{overlay} /.var/var-chr")
            os.system(f"btrfs sub snap /.boot/etc-{overlay} /.boot/boot-chr")
            os.system(f"cp -r --reflink=auto /.etc/etc-chr/* /.overlays/overlay-chr/etc")
            os.system(f"cp -r --reflink=auto /.var/var-chr/* /.overlays/overlay-chr/var")
            os.system(f"cp -r --reflink=auto /.boot/boot-chr/* /.overlays/overlay-chr/boot")
            os.system("pacstrap /.overlays/overlay-chr")
            os.system(f"pacman -r /.overlays/overlay-chr -S {pkg}")
            os.system(f"btrfs sub del /.overlays/overlay-{int(i)}")
            os.system(f"btrfs sub snap -r /.overlays/overlay-chr /.overlays/overlay-{int(i)}")
            os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/etc/* /.etc/etc-chr")
            os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/var/* /.etc/var-chr")
            os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/boot/* /.etc/boot-chr")
            os.system(f"btrfs sub del /.etc/etc-{int(etc)}")
            os.system(f"btrfs sub del /.var/var-{int(etc)}")
            os.system(f"btrfs sub del /.boot/boot-{int(etc)}")
            os.system(f"btrfs sub snap -r /.etc/etc-chr /.etc/etc-{int(etc)}")
            os.system(f"btrfs sub snap -r /.var/var-chr /.var/var-{int(etc)}")
            os.system(f"btrfs sub snap -r /.boot/boot-chr /.boot/boot-{int(etc)}")
            os.system(f"btrfs sub del .overlays/overlay-{tmp}")
            os.system(f"btrfs sub snap /.overlay/overlay-{int(i)} /.overlays/overlay-{tmp}")
            os.system(f"cp --reflink=auto -r /.etc/etc-{int(i)}/* /.overlays/overlay-{tmp}/etc")
            os.system(f"cp --reflink=auto -r /.var/var-{int(i)}/* /.overlays/overlay-{tmp}/var")
            os.system(f"cp --reflink=auto -r /.boot/boot-{int(i)}/* /.overlays/overlay-{tmp}/boot")
            switchtmp()
            break

def switchtmp():
    mount = str(subprocess.check_output("mount", shell=True))
    if "tmp0" in mount:
        os.system("sed -i 's,subvol=@.overlays/overlay-tmp0,subvol=@.overlays/overlay-tmp,' /boot/grub/grub.cfg")
        os.system("sed -i 's,@.overlays/overlay-tmp0,@.overlays/overlay-tmp,' /etc/fstab")
        os.system("sed -i 's,@.etc/etc-tmp0,@.etc/etc-tmp,' /etc/fstab")
        os.system("sed -i 's,@.var/var-tmp0,@.var/var-tmp,' /etc/fstab")
        os.system("sed -i 's,@.boot/boot-tmp0,@.boot/boot-tmp,' /etc/fstab")
        os.system("btrfs sub set-default /.overlays/overlay-tmp")
    else:
        os.system("sed -i 's,subvol=@.overlays/overlay-tmp,subvol=@.overlays/overlay-tmp0,' /boot/grub/grub.cfg")
        os.system("sed -i 's,@.overlays/overlay-tmp,@.overlays/overlay-tmp0,' /etc/fstab")
        os.system("sed -i 's,@.etc/etc-tmp,@.etc/etc-tmp0,' /etc/fstab")
        os.system("sed -i 's,@.var/var-tmp,@.var/var-tmp0,' /etc/fstab")
        os.system("sed -i 's,@.boot/boot-tmp,@.boot/boot-tmp0,' /etc/fstab")
        os.system("btrfs sub set-default /.overlays/overlay-tmp0")

def ls_overlay():
    overlays = os.listdir("/.overlays")
    descs = []
    for overlay in overlays:
        if os.path.isfile(f"/root/images/desc-{overlay}"):
            overfile = open(f"/root/images/desc-{overlay}")
            descs.append(str(overfile.readline()))
        else:
            descs.append("")
    for index in range(0, len(overlays)-1,+1):
        print(f"{overlays[index]} - {descs[index]}")


def mk_img(imgpath):
    i = 0
    overlays = os.listdir("/.overlays")
    etcs = os.listdir("/.etc")
    vars = os.listdir("/.var")
    boots = os.listdir("/.boot")
    overlays.append(etcs)
    overlays.append(vars)
    overlays.append(boots)
    while True:
        i += 1
        if str(f"overlay-{i}") not in overlays and str(f"etc-{i}") not in overlays and str(f"var-{i}") not in overlays and str(f"boot-{i}") not in overlays:
            os.system(f"btrfs sub snap -r /.base/base /.overlays/overlay-{i}")
            os.system(f"btrfs sub snap -r /.etc/etc-0 /.etc/etc-{i}")
            os.system(f"btrfs sub snap -r /.var/var-0 /.var/var-{i}")
            os.system(f"btrfs sub snap -r /.boot/boot-0 /.boot/boot-{i}")
            break
    os.system(f"btrfs sub snap /.overlays/overlay-{i} /.overlays/overlay-chr")
    os.system(f"btrfs sub snap /.etc/etc-{i} /.etc/etc-chr")
    os.system(f"btrfs sub snap /.var/var-{i} /.var/var-chr")
    os.system(f"btrfs sub snap /.boot/boot-{i} /.boot/boot-chr")
    os.system(f"cp -r --reflink=auto /.etc/etc-chr/* /.overlays/overlay-chr/etc")
    os.system(f"cp -r --reflink=auto /.var/var-chr/* /.overlays/overlay-chr/var")
    os.system(f"cp -r --reflink=auto /.boot/boot-chr/* /.overlays/overlay-chr/boot")
    os.system(f"cp -r {imgpath} /.overlays/overlay-chr/init.py")
    os.system("pacstrap /.overlays/overlay-chr")
    os.system("arch-chroot /.overlays/overlay-chr python3 /init.py")
    os.system(f"btrfs sub del /.overlays/overlay-{i}")
    os.system(f"btrfs sub snap -r /.overlays/overlay-chr /.overlays/overlay-{i}")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/etc/* /.etc/etc-chr")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/var/* /.var/var-chr")
    os.system(f"cp -r --reflink=auto /.overlays/overlay-chr/boot/* /.boot/boot-chr")
    os.system(f"btrfs sub del /.etc/etc-{i}")
    os.system(f"btrfs sub del /.var/var-{i}")
    os.system(f"btrfs sub del /.boot/boot-{i}")
    os.system(f"btrfs sub snap -r /.etc/etc-chr /.etc/etc-{i}")
    os.system(f"btrfs sub snap -r /.var/var-chr /.var/var-{i}")
    os.system(f"btrfs sub snap -r /.boot/boot-chr /.boot/boot-{i}")


def main(args):
    overlay = get_overlay()
    etc = overlay
    for arg in args:
        if arg == "new-overlay" or arg == "new":
            new_overlay()
            break
        elif arg == "chroot" or arg == "cr":
            chroot(args[args.index(arg)+1])
            break
        elif arg == "install" or arg == "i":
            install(args[args.index(arg)+1],args[args.index(arg)+2])
            break
        elif arg == "cinstall" or arg == "ci":
            cinstall(overlay,args[args.index(arg)+1])
            break
        elif arg == "clone":
            clone(args[args.index(arg)+1])
            break
        elif arg == "list" or arg == "l":
            ls_overlay()
            break
        elif arg == "mk-img" or arg == "img":
            mk_img(args[args.index(arg)+1])
            break
        elif arg == "deploy":
            deploy(args[args.index(arg)+1])
            break
        elif arg == "upgrade" or arg == "up":
            upgrade(args[args.index(arg)+1])
        else:
            print("No operation entered.")



main(args)
