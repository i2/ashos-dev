import oss as os
import time
import sys

args = list(sys.argv)
# startup-service; startup; astpk-part; astpk-cbase; astpk-coverlay; astpk-firstboot

def updateetc(args):
    os.system("umount /mnt/etc")
    os.system("mkdir /mnt/etc-tmp")
    os.system(f"mount {args[1]} -o subvol=@etc,compress=zstd,noatime /mnt/etc-tmp")
    os.system("cp -r /mnt/etc-tmp/* /mnt/etc/")
    os.system("umount /mnt/etc-tmp")
    os.system(f"mount {args[1]} -o subvol=@etc,compress=zstd,noatime /mnt/etc")


def main(args):
    os.system("pacman -Sy")
    os.system("pacman -S vim")
    confirm = "n"
    os.system("lsblk")
    os.system(f"mkfs.btrfs -f {args[1]}")
#    if os.path.exists("/sys/firmware/efi"):
#        efi = True
#    else:
#        efi = False
    efi = False #
    os.system(f"mount {args[1]} /mnt")
    os.system(f"mkfs.ext4 {args[2]}")
    btrdirs = ["@","@var","@etc","@.etc","@opt","@.overlays","@.base","@home","@tmp","@.boot","@root"]
    mntdirs = ["","var","etc",".etc","opt",".overlays",".base","home","tmp",".boot","root"]
    for btrdir in btrdirs:
        os.system(f"btrfs sub create /mnt/{btrdir}")
    os.system(f"umount /mnt")
    os.system(f"mount {args[1]} -o subvol=@,compress=zstd,noatime /mnt")
    os.system("mkdir /mnt/boot")
    os.system(f"mount {args[2]} /mnt/boot")
    for mntdir in mntdirs:
        os.system(f"mkdir /mnt/{mntdir}")
        os.system(f"mount {args[1]} -o subvol={btrdirs[mntdirs.index(mntdir)]},compress=zstd,noatime /mnt/{mntdir}")
    if efi:
        os.system("mkdir /mnt/boot/efi")
        os.system(f"mount {args[4]} /mnt/boot/efi")
    os.system("pacstrap /mnt base linux-lts linux-firmware dhcpcd btrfs-progs python3 arch-install-scripts networkmanager grub")
    mntdirs_n = mntdirs
    mntdirs_n.remove("")
    os.system(f"echo '{args[1]} / btrfs subvol=@,compress=zstd,noatime,ro 0 0' > /mnt/etc/fstab")
    for mntdir in mntdirs_n:
        os.system(f"echo '{args[1]} /{mntdir} btrfs subvol=@{mntdir},compress=zstd,noatime 0 0' >> /mnt/etc/fstab")
    if efi:
        os.system(f"echo '{args[3]} /boot/efi vfat umask=0077 0 2' >> /mnt/etc/fstab")
    os.system(f"echo '{args[2]} /boot/ ext4 defaults 0 1' >> /mnt/etc/fstab")
    os.system("mkdir /mnt/etc/astpk.d")
    os.system("touch /mnt/etc/astpk.d/astpk-firstboot")
    os.system(f"echo '{args[1]}' > /mnt/etc/astpk.d/astpk-part")
    os.system(f"echo '0' > /mnt/etc/astpk.d/astpk-coverlay")
    os.system(f"echo '0' > /mnt/etc/astpk.d/astpk-cbase")
    os.system(f"echo '/sbin/mount -o subvol=@.overlays/overlay-tmp,noatime,compress=zstd {args[1]} /' > /mnt/etc/astpk.d/startup")
    os.system(f"echo '/bin/cp -r --reflink=always /.base/base-0/* /' >> /mnt/etc/astpk.d/startup")
    os.system(f"echo '[Unit]' > /mnt/etc/astpk.d/startup-service")
    os.system(f"echo 'Description=Copy files for OS' >> /mnt/etc/astpk.d/startup-service")
    os.system(f"echo 'After=var.mount' >> /mnt/etc/astpk.d/startup-service")
    os.system(f"echo '[Service]' >> /mnt/etc/astpk.d/startup-service")
    os.system(f"echo 'ExecStart=/etc/astpk.d/startup' >> /mnt/etc/astpk.d/startup-service")
    os.system(f"echo '[Install]' >> /mnt/etc/astpk.d/startup-service")
    os.system(f"echo 'WantedBy=multi-user.target' >> /mnt/etc/astpk.d/startup-service")
    updateetc(args)
    while True:
        print("Select a timezone (type list to list):")
        zone = input("> ")
        if zone == "list":
            os.system("ls /usr/share/zoneinfo | less")
        else:
            timezone = str(f"/usr/share/timezone/{zone}")
            break
    os.system(f"arch-chroot /mnt ln -sf {timezone} /etc/localtime")
    print("Uncomment your desired locale:")
    input()
    os.system("vim /mnt/etc/locale.gen")
    os.system(f"arch-chroot /mnt locale-gen")
    os.system(f"arch-chroot /mnt hwclock --systohc")
    print("Set locale in format 'LANG=en_US.UTF8'")
    input()
    os.system(f"vim /mnt/etc/locale.conf")
    print("Set keyload in format 'KEYMAP=us'")
    input()
    os.system(f"vim /mnt/etc/vconsole.conf")
    print("Enter hostname:")
    hostname = input("> ")
    os.system(f"echo {hostname} > /mnt/etc/hostname")

    os.system("cp /mnt/etc/astpk.d/startup-service /mnt/etc/systemd/system/recp.service")
    os.system("sed -i '0,/@/{s,@,@.overlays/overlay-tmp,}' /mnt/etc/fstab")
    os.system("arch-chroot /mnt echo 'userid:newpasswd' | chpasswd")
    os.system("arch-chroot /mnt btrfs sub set-default /.overlays/overlay-tmp")
    os.system("arch-chroot /mnt echo -e 'nopass\nnopass' | passwd root")
    os.system("umount /mnt/boot")
    os.system(f"arch-chroot /mnt grub-install {args[1]}")
    os.system(f"arch-chroot /mnt grub-mkconfig {args[3]} -o /boot/grub/grub.cfg")
    os.system("sed -i '0,/subvol=@/{s,subvol=@,subvol=@.overlays/overlay-tmp,}' /mnt/boot/grub/grub.cfg")
    os.system("mkdir /mnt/boot-tmp")
    os.system(f"mount {args[2]} /mnt/boot-tmp")
    os.system("cp -r --reflink=auto /mnt/boot/* /mnt/boot/tmp")
    os.system("umount /mnt/boot-tmp")
    os.system(f"mount {args[2]} /mnt/boot")
    os.system("btrfs sub snap -r /mnt /mnt/.base/base-0")
    os.system("btrfs sub snap -r /mnt /mnt/.overlays/overlay-0")
    os.system("btrfs sub create /mnt/.boot/boot-tmp")
    os.system("cp --reflink=auto -r /mnt/boot /mnt/.boot/boot-tmp")
    os.system("btrfs sub snap -r /mnt/.boot/boot-tmp /mnt/.boot/boot-0")
    os.system("btrfs sub snap /mnt/.overlays/overlay-0 /mnt/.overlays/overlay-tmp")
    os.system("btrfs sub snap -r /mnt/etc /mnt/.etc/etc-0")
    updateetc(args)
    print("You can reboot now :)")

main(args)
