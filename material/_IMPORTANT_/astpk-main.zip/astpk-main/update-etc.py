import os
import sys

args = list(sys.argv)

def main(args):
    os.system("umount /mnt/etc")
    os.system("mkdir /mnt/etc-tmp")
    os.system(f"mount {args[1]} -o subvol=@etc,compress=zstd,noatime /mnt/etc-tmp")
    os.system("cp -r /mnt/etc-tmp/* /mnt/etc/")
    os.system("umount /mnt/etc-tmp")
    os.system(f"mount {args[1]} -o subvol=@etc,compress=zstd,noatime /mnt/etc")

    os.system(f"mount {args[1]} /mnt/boot")


main(args)